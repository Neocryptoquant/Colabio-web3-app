import { ProjectDiscovery } from "@/components/project-discovery"

export default function DiscoverPage() {
  return <ProjectDiscovery />
}
