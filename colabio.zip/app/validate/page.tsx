import { CommunityValidation } from "@/components/community-validation"

export default function ValidatePage() {
  return <CommunityValidation />
}
