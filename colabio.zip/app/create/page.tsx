import { ProjectCreation } from "@/components/project-creation"

export default function CreatePage() {
  return <ProjectCreation />
}
